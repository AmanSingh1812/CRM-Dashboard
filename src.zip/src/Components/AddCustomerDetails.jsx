// src/Components/AddCustomerDetails.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";

function AddCustomerDetails({ user, setCustomerDetails }) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const colRef = collection(db, "customers");
      const docRef = await addDoc(colRef, {
        ...form,
        createdAt: serverTimestamp(),
        salespersonId: user?.uid || null, // Assign current user ID
      });

      // Update the state in App.jsx
      setCustomerDetails((prev) => [
        ...prev,
        { id: docRef.id, ...form, salespersonId: user?.uid },
      ]);

      // Clear form or navigate
      setForm({ name: "", email: "", phone: "", address: "" });
      navigate("/customerdetails");
    } catch (error) {
      console.error("Error adding customer:", error);
    }
  };

  return (
    <div>
      <h2>Add Customer</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="phone"
          placeholder="Phone"
          value={form.phone}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="address"
          placeholder="Address"
          value={form.address}
          onChange={handleChange}
          required
        />
        <button type="submit">Add Customer</button>
      </form>
    </div>
  );
}

export default AddCustomerDetails;
