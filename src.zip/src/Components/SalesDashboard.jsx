// src/Components/SalesDashboard.jsx
import { useEffect, useState } from "react";
import { collection, onSnapshot, query, where } from "firebase/firestore";
import { db } from "../firebase";

function SalesDashboard({ user }) {
  const [myCustomers, setMyCustomers] = useState([]);

  useEffect(() => {
    if (!user) return;

    // Example: Only fetch customers assigned to this salesperson
    const q = query(
      collection(db, "customers"),
      where("salespersonId", "==", user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setMyCustomers(data);
    });

    return () => unsubscribe();
  }, [user]);

  return (
    <div>
      <h2>Sales Dashboard</h2>
      <p>Total My Customers: {myCustomers.length}</p>
      <ul>
        {myCustomers.map((customer) => (
          <li key={customer.id}>
            {customer.name} - {customer.email} - {customer.phone}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default SalesDashboard;
