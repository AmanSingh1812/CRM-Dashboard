// src/Components/CustomerDetails.jsx
import { useEffect, useState } from "react";
import {
  collection,
  deleteDoc,
  doc,
  updateDoc,
  onSnapshot,
} from "firebase/firestore";
import { db } from "../firebase";

function CustomerDetails({ customerDetails, setCustomerDetails }) {
  const [editingId, setEditingId] = useState(null);
  const [editingData, setEditingData] = useState({});

  // Real-time subscription to customers collection
  useEffect(() => {
    const colRef = collection(db, "customers");
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setCustomerDetails(data);
    });

    return () => unsubscribe(); // Cleanup listener on unmount
  }, [setCustomerDetails]);

  // Delete customer
  const handleDelete = async (id) => {
    try {
      await deleteDoc(doc(db, "customers", id));
    } catch (error) {
      console.error("Error deleting customer:", error);
    }
  };

  // Start editing
  const handleEdit = (customer) => {
    setEditingId(customer.id);
    setEditingData({
      name: customer.name,
      email: customer.email,
      phone: customer.phone,
      address: customer.address,
    });
  };

  // Save updates to Firestore
  const handleSave = async (id) => {
    try {
      const docRef = doc(db, "customers", id);
      await updateDoc(docRef, editingData);
      setEditingId(null);
      setEditingData({});
    } catch (error) {
      console.error("Error updating customer:", error);
    }
  };

  const handleChange = (e) => {
    setEditingData({ ...editingData, [e.target.name]: e.target.value });
  };

  return (
    <div>
      <h2>Customer List</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {customerDetails.map((customer) => (
            <tr key={customer.id}>
              <td>
                {editingId === customer.id ? (
                  <input
                    name="name"
                    value={editingData.name}
                    onChange={handleChange}
                  />
                ) : (
                  customer.name
                )}
              </td>
              <td>
                {editingId === customer.id ? (
                  <input
                    name="email"
                    value={editingData.email}
                    onChange={handleChange}
                  />
                ) : (
                  customer.email
                )}
              </td>
              <td>
                {editingId === customer.id ? (
                  <input
                    name="phone"
                    value={editingData.phone}
                    onChange={handleChange}
                  />
                ) : (
                  customer.phone
                )}
              </td>
              <td>
                {editingId === customer.id ? (
                  <input
                    name="address"
                    value={editingData.address}
                    onChange={handleChange}
                  />
                ) : (
                  customer.address
                )}
              </td>
              <td>
                {editingId === customer.id ? (
                  <>
                    <button onClick={() => handleSave(customer.id)}>
                      Save
                    </button>
                    <button
                      onClick={() => {
                        setEditingId(null);
                        setEditingData({});
                      }}
                    >
                      Cancel
                    </button>
                  </>
                ) : (
                  <>
                    <button onClick={() => handleEdit(customer)}>Edit</button>
                    <button onClick={() => handleDelete(customer.id)}>
                      Delete
                    </button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CustomerDetails;
