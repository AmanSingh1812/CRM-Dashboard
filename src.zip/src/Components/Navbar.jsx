import { Link, Outlet } from "react-router-dom";
import logo from "../assets/Logo.gif";

function Navbar({ user, onLogout }) {
  if (!user) return null;

  return (
    <>
      <nav className="flex justify-between items-center p-4 shadow-md">
        <img src={logo} alt="Logo" width="100px" className="p-2 ml-8" />
        <ul className="flex gap-6 mr-8 items-center">
          {/* Common Links for admin & sales */}
          {(user.role === "admin" || user.role === "sales") && (
            <>
              <li>
                <Link
                  to="/addcustomerdetails"
                  className="hover:text-blue-600 font-medium"
                >
                  Add Customer Details
                </Link>
              </li>
              <li>
                <Link
                  to="/customerdetails"
                  className="hover:text-blue-600 font-medium"
                >
                  Customer Details
                </Link>
              </li>
            </>
          )}

          {/* Admin Dashboard */}
          {user.role === "admin" && (
            <li>
              <Link to="/dashboard" className="hover:text-blue-600 font-medium">
                Dashboard
              </Link>
            </li>
          )}

          {/* Sales Dashboard */}
          {user.role === "sales" && (
            <li>
              <Link
                to="/sales-dashboard"
                className="hover:text-blue-600 font-medium"
              >
                My Sales Dashboard
              </Link>
            </li>
          )}

          {/* Logout Button */}
          <li>
            <button
              onClick={onLogout}
              className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600"
            >
              Logout
            </button>
          </li>
        </ul>
      </nav>
      <Outlet />
    </>
  );
}

export default Navbar;
