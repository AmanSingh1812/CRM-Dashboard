export default function Unauthorized() {
  return <h1 style={{ color: "red" }}>Unauthorized access 🚫</h1>;
}
