import { Routes, Route, useNavigate } from "react-router-dom";
import Navbar from "./Components/Navbar";
import Dashboard from "./Components/Dashboard";
import AddCustomerDetails from "./Components/AddCustomerDetails";
import CustomerDetails from "./Components/CustomerDetails";
import Login from "./Components/Login";
import AdminDashboard from "./Components/AdminDashboard";
import SalesDashboard from "./Components/SalesDashboard";
import ProtectedRoute from "./Components/ProtectedRoute";
import { useEffect, useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth, db } from "./firebase";
import { doc, getDoc, collection, onSnapshot } from "firebase/firestore";

function App() {
  const [customerDetails, setCustomerDetails] = useState([]);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  // Listen to auth state and fetch user data from Firestore
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        const userRef = doc(db, "users", currentUser.uid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          setUser({ uid: currentUser.uid, ...userSnap.data() });
        } else {
          setUser(null);
          await signOut(auth);
        }
      } else {
        setUser(null);
      }
    });

    return () => unsubscribe();
  }, []);

  // Real-time subscription to customers collection
  useEffect(() => {
    const colRef = collection(db, "customers");
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setCustomerDetails(data);
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    navigate("/login");
  };

  return (
    <>
      <Navbar user={user} onLogout={handleLogout} />
      <Routes>
        <Route path="/" element={<Login setUser={setUser} />} />
        <Route path="/login" element={<Login setUser={setUser} />} />

        <Route
          path="/admin-dashboard"
          element={
            <ProtectedRoute user={user} allowedRoles={["admin"]}>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-dashboard"
          element={
            <ProtectedRoute user={user} allowedRoles={["salesperson"]}>
              <SalesDashboard user={user} />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute user={user} allowedRoles={["admin"]}>
              <Dashboard customerDetails={customerDetails} />
            </ProtectedRoute>
          }
        />
        <Route
          path="/addcustomerdetails"
          element={
            <ProtectedRoute user={user} allowedRoles={["admin", "salesperson"]}>
              <AddCustomerDetails
                user={user}
                setCustomerDetails={setCustomerDetails}
              />
            </ProtectedRoute>
          }
        />
        <Route
          path="/customerdetails"
          element={
            <ProtectedRoute user={user} allowedRoles={["admin"]}>
              <CustomerDetails
                customerDetails={customerDetails}
                setCustomerDetails={setCustomerDetails}
              />
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  );
}

export default App;
